const bbmmap = require('../bbmmap.node')

const handle = bbmmap.openProcess(50592);

bbmmap.mmap(handle, require('fs').readFileSync('./discordoverlay_dx11.dll'))
console.log(bbmmap);

setInterval(() => {}, )